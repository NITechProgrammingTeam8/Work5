KdTree
======

A fast, generic, multi-dimensional Binary Search Tree written in C#

Forked from [codeandcats KdTree](https://github.com/codeandcats/KdTree).

## Changes from KdTree

This branch is modified to compile for .NET Framework 3.5, and removes the non-MIT licensed GeoUtils class.

